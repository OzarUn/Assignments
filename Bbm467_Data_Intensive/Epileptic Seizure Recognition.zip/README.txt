Group 25

Ozar Ömer Uncu	- 21727815
Uğurcan Bağrıyanık - 21526701

Youtube Link: https://youtu.be/3LrhrWp5hEk

Dataset : 
https://archive.ics.uci.edu/ml/index.php
https://www.kaggle.com/harunshimanto/epileptic-seizure-recognition